# MEME HUNTER BOT 1.0 — Demo

Ứng dụng web tĩnh chạy trên trình duyệt, ưu tiên iPhone. Chỉ quét dữ liệu công khai từ DEX Screener và mô phỏng giao dịch bằng số dư ảo $100.

## Cách chạy trên iPhone
1. Tải file ZIP và giải nén trong ứng dụng Tệp (Files).
2. Mở `index.html` bằng Safari nếu iOS cho phép mở trang HTML cục bộ.
3. Nếu Safari chặn yêu cầu API từ file cục bộ, tải `index.html` lên GitHub Pages hoặc một dịch vụ static hosting HTTPS rồi mở URL đó trên Safari.
4. Bấm **Quét ngay**. Bật **Tự động Demo** để quét khoảng mỗi 60 giây khi trang đang mở.

## Chức năng
- Lấy danh sách token profiles mới nhất từ DEX Screener.
- Lấy pools/token pairs theo chain và token address.
- Lọc theo thanh khoản, volume 24h và điểm tín hiệu.
- Tự mô phỏng mua/bán; TP +20%, SL -10%, vốn ảo $100, mỗi lệnh $5, tối đa 3 vị thế.
- Lưu trạng thái Demo trong localStorage của trình duyệt.

## Giới hạn quan trọng
- Đây là prototype thử nghiệm, không phải bot giao dịch thật, không kết nối MetaMask và không gửi giao dịch on-chain.
- Chỉ kiểm tra một tập nhỏ token profile mỗi vòng quét; không phải toàn bộ token mới trên mọi DEX.
- Điểm số là heuristic đơn giản, không phải AI dự báo và không chứng minh token an toàn.
- Chưa tích hợp honeypot/rug-pull verification. Dữ liệu DEX Screener không đủ để xác nhận hợp đồng an toàn.
- Safari có thể tạm dừng timer khi chạy nền/khóa màn hình. Không chạy 24/7.
- Kết quả mô phỏng có thể sai khác đáng kể so với giao dịch thật do thanh khoản, MEV, thuế token, trượt giá, phí mạng và độ trễ.
- Không nhập seed phrase, private key hoặc API key vào ứng dụng này.

## Nguồn
- DEX Screener API: https://docs.dexscreener.com/api/reference
- GoPlus security API (cần tích hợp riêng và kiểm tra hỗ trợ từng chain): https://docs.gopluslabs.io/
- MetaMask networks: https://support.metamask.io/configure/networks/

## Trước khi có giao dịch thật
Cần bổ sung: backend chạy liên tục, kiểm tra bảo mật token theo chain, xác thực thanh khoản/owner/LP, giới hạn rủi ro, mô phỏng giao dịch, cảnh báo, kiểm soát quyền ký giao dịch và kiểm thử độc lập. Không nên dùng số vốn 500.000 VNĐ cho đến khi thử nghiệm đủ lâu và hiểu rõ rủi ro.
